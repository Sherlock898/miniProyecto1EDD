#include <iostream>
#include <chrono>
#include "sdsl/int_vector.hpp"

using namespace sdsl;
using namespace std;

template <class T, int width>
int create_vector(FILE* data, int samples, const char* save_name){
	fseek(data, 0, SEEK_SET);
	T x(samples);
	for(int i = 0; i < samples; i++){
		int a;
		if(!fread(&a, width, 1, data)){
			cout << "Error reading file" << endl;
			return EXIT_FAILURE;
		}
		x[i] = a;
	}
	store_to_file(x, save_name);
	return EXIT_SUCCESS;
}

template <class T, int width>
int test_vector(FILE* fout, FILE* values, int ntests, const char* save_name){
	rewind(values);
	int valor;
	while(fscanf(values, "%d", &valor) != EOF){
		cout << valor <<": ";
		T x;
		load_from_file(x, save_name);
		auto start = chrono::high_resolution_clock::now();
		for (int i = 0; i < ntests; i++)
		{
			for (int j = 0; j < x.size(); j++)
			{
				if(x[j] == valor){
					cout << "Found " << valor << " at " << j << endl; // "Found
					break;
				}
			}
		}
		auto end = chrono::high_resolution_clock::now();
		auto duration = chrono::duration<double>(end - start);
		fprintf(fout, "%d, %d, %d, %d, %lf\n", width, valor, ntests, x.size(), duration*1000);
	}

	return EXIT_SUCCESS;
}

int main(){
	FILE *data_1 = fopen("datasets/dblp.100MB.1B.bwt", "rb");
	FILE *data_4 = fopen("datasets/dblp.100MB.4B.lcp", "rb");
	FILE *search_values = fopen("datasets/search_values.data", "r");
	FILE *fdata_out = fopen("datasets/cResults.csv", "w+");

	fprintf(fdata_out, "width, valor, ntests, size, time\n");

	create_vector<int_vector<8>, 1>(data_1, 10000000, "1B_intvector");

	int_vector<8> v;
	test_vector<int_vector<8>, 1>(fdata_out, search_values, 10, "1B_intvector");

	fclose(data_1);
	fclose(data_4);
	//fclose(fout);
	return 0;
}
